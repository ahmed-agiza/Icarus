#include <string>

using namespace std;

#ifndef PERMISSION_H
#define PERMISSION_H
class permission
{
public:
    permission() {}
    int views;
    string name;
};
#endif // PERMISSION_H

